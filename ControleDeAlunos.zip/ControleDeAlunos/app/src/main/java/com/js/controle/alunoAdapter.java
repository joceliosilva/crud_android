package com.js.controle;
import android.app.*;
import android.view.*;
import android.widget.*;
import com.js.controle.model.*;
import java.util.*;

public class alunoAdapter extends BaseAdapter
{
    private List<Aluno> alunos;
    private Activity activity;

    public alunoAdapter(Activity activity, List<Aluno> alunos)
    {
        this.activity = activity;
        this.alunos = alunos;
    }

    @Override
    public int getCount()
    {
        // TODO: Implement this method
        return alunos.size();
    }

    @Override
    public Object getItem(int p1)
    {
        // TODO: Implement this method
        return alunos.get(p1);
    }

    @Override
    public long getItemId(int p1)
    {
        // TODO: Implement this method
        return alunos.get(p1).getId();
    }

    @Override
    public View getView(int p1, View view, ViewGroup viewgroup)
    {
        View v = activity.getLayoutInflater().inflate(R.layout.dados, viewgroup, false);
        TextView nome = v.findViewById(R.id.dnome);
        TextView cpf = v.findViewById(R.id.dcpf);
        TextView telefone = v.findViewById(R.id.dtelefone);

        Aluno a = alunos.get(p1);
        nome.setText(a.getNome());
        cpf.setText(a.getCpf());
        telefone.setText(a.getTelefone());


        return v;
    }

}
