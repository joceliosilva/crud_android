package com.js.controle.model;
import java.io.*;

public class Aluno implements Serializable
{
    private Integer id;
    private String nome;
    private String cpf;
    private String telefone;


    public void setId(int id)
    {
        this.id = id;
    }

    public Integer getId()
    {
        return id;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getNome()
    {
        return nome;
    }

    public void setCpf(String cpf)
    {
        this.cpf = cpf;
    }

    public String getCpf()
    {
        return cpf;
    }

    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }

    public String getTelefone()
    {
        return telefone;
    }

    @Override
    public String toString()
    {
        // TODO: Implement this method
        return nome;

    }


}
