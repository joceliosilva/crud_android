package com.js.controle.dao;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import com.js.controle.dbhelper.*;
import com.js.controle.model.*;
import java.util.*;

public class AlunoDao
{
    private dbhelper db;
    private SQLiteDatabase data;


    public AlunoDao(Context context)
    {
        db = new dbhelper(context);
        data = db.getWritableDatabase();
    }
    public long inserir(Aluno aluno)
    {
        ContentValues values = new ContentValues();
        values.put("nome", aluno.getNome());
        values.put("cpf", aluno.getCpf());
        values.put("telefone", aluno.getTelefone());
        return data.insert("aluno", null, values);
    }

   public List<Aluno> obtertodos()
    {
        List<Aluno> alunos = new ArrayList<>();
        Cursor cursor= data.query("aluno", new String [] {"id","nome","cpf","telefone"}, null, null, null, null, null);

        while (cursor.moveToNext())
        {
            Aluno a = new Aluno();
            a.setId(cursor.getInt(0));
            a.setNome(cursor.getString(1));
            a.setCpf(cursor.getString(2));
            a.setTelefone(cursor.getString(3));
            alunos.add(a);
            }

        return alunos;
    }
    public void excluir(Aluno a)
    {
        data.delete("aluno", "id=?", new String[]{a.getId().toString()});

    }
    public void atualizar(Aluno aluno)
    {
        ContentValues values = new ContentValues();
        values.put("nome", aluno.getNome());
        values.put("cpf", aluno.getCpf());
        values.put("telefone", aluno.getTelefone());
        data.update("aluno", values, "id=?", new String[]{aluno.getId().toString()});
    }
}
