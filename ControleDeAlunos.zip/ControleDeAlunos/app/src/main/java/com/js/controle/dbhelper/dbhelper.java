package com.js.controle.dbhelper;

import android.content.*;
import android.database.sqlite.*;

public class  dbhelper extends SQLiteOpenHelper
{
    private static final int VERSAO_DB= 1;
    private static final String NOME_DB= "banco.db";

    public dbhelper(Context context)
    {
        super(context, NOME_DB, null, VERSAO_DB);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table aluno(id integer primary key autoincrement,nome varchar (50), cpf varchar (50), telefone varchar (50))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1)
    {
        // TODO: Implement this method
    }

}
