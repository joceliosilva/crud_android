package com.js.controle;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.js.controle.dao.*;
import com.js.controle.model.*;
import com.js.controle.util.*;


public class MainActivity extends Activity
{

    EditText nome, cpf, telefone;
    Button salvar;
    private AlunoDao dao;
    private Aluno aluno=null;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // instancia das variaveis 
        
        nome = (EditText)findViewById(R.id.edtnome);
        cpf = (EditText) findViewById(R.id.edtcpf);
        telefone = (EditText) findViewById(R.id.edttelefone);
        salvar = (Button) findViewById(R.id.btnsalvar);
        dao = new AlunoDao(this);

        // mascara dos campos 
        cpf.addTextChangedListener(MaskEditUtil.mask(cpf, MaskEditUtil.FORMAT_CPF));
        telefone.addTextChangedListener(MaskEditUtil.mask(telefone, MaskEditUtil.FORMAT_FONE));

        Intent it = getIntent();
        if (it.hasExtra("aluno"))
        {
            aluno = (Aluno) it.getSerializableExtra("aluno");
            nome.setText(aluno.getNome());
            cpf.setText(aluno.getCpf());
            telefone.setText(aluno.getTelefone());

        }

    }

    public void salvar(View view)
    {
        if (validar())
        {
            if (aluno == null)
            {
                aluno = new Aluno();
                aluno.setNome(nome.getText().toString());
                aluno.setCpf(cpf.getText().toString());
                aluno.setTelefone(telefone.getText().toString());
                long id = dao.inserir(aluno);
                limparcampos();
                this.finish();
                Toast.makeText(this, " Salvo!", Toast.LENGTH_SHORT).show();
  }
            else
            {
                aluno.setNome(nome.getText().toString());
                aluno.setCpf(cpf.getText().toString());
                aluno.setTelefone(telefone.getText().toString());
                dao.atualizar(aluno);
                Toast.makeText(this, " Atualizado!", Toast.LENGTH_SHORT).show();
                finish();
            }}

    }
    
    public void limparcampos()
    {
        nome.setText("");
        cpf.setText("");
        telefone.setText("");
    }
    
    // classe para verificar se os campos estao preenchidos
    public boolean validar()
    {
        boolean retorno= true;

        String c1 = nome.getText().toString();
        String c2 = cpf.getText().toString();
        String c3 = telefone.getText().toString();

        if (c1.isEmpty())
        {
            nome.setError("Preencha esse campo!");
            retorno = false;
        }
        if (c2.isEmpty())
        {
            cpf.setError("Preencha esse campo!");
            retorno = false;
        }
        if (c3.isEmpty())
        {
            telefone.setError("Preencha esse campo!");
            retorno = false;
        }
        return retorno;
    }
}
