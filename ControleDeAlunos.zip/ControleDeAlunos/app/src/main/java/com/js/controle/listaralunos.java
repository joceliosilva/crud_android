package com.js.controle;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.js.controle.dao.*;
import com.js.controle.model.*;
import java.util.*;


public class listaralunos extends Activity
{
    private ListView lista;
    private AlunoDao dao;
    private List<Aluno> alunos;
    private List<Aluno> alunosfiltrados = new ArrayList<>() ;
    private Button cad;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        // TODO: Implement this method
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listaralunos);

        lista = (ListView) findViewById(R.id.list1);
        dao = new AlunoDao(this);
        alunos = dao.obtertodos();
        alunosfiltrados.addAll(alunos);

        cad = (Button) findViewById(R.id.cad);

        cad.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {
                    Intent i= new Intent(listaralunos.this, MainActivity.class);
                    startActivity(i);
                }


            });
        alunoAdapter adapter = new alunoAdapter(this, alunosfiltrados);
        lista.setAdapter(adapter);
        registerForContextMenu(lista);
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.mainmenu, menu);
        // TODO: Implement this method

        SearchView sv = (SearchView)menu.findItem(R.id.app_search_bar).getActionView();
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener(){

                @Override
                public boolean onQueryTextChange(String s)
                {
                    procuraraluno(s);
                    return false;
                }


                public boolean onQueryTextSubmit(String s)
                {

                    return false;
                }
            });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        getMenuInflater().inflate(R.menu.menucontexto, menu);

        // TODO: Implement this method
        super.onCreateContextMenu(menu, v, menuInfo);
    }



    public void procuraraluno(String nome)
    {
        alunosfiltrados.clear();
        for (Aluno a: alunos)
        {
            if (a.getNome().toLowerCase().contains(nome.toLowerCase()))
            {
                alunosfiltrados.add(a);
            }
        }
        lista.invalidateViews();
    }



    public void excluir(MenuItem item)
    {
        AdapterView.AdapterContextMenuInfo menuInfo= (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        final Aluno alunoExcluir= alunosfiltrados.get(menuInfo.position);

        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
            .setTitle("Atenção!")
            .setMessage("Deseja excluir?")
            .setNegativeButton("NÃO", null)
            .setPositiveButton("SIM", new DialogInterface.OnClickListener(){

                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    alunosfiltrados.remove(alunoExcluir);
                    alunos.remove(alunoExcluir);
                    dao.excluir(alunoExcluir);
                    lista.invalidateViews();
                }

            });dialog.show();
    }


    public void cadastrar(MenuItem item)
    {
        Intent it= new Intent(this, MainActivity.class);
        startActivity(it);

    }
  
    public void add()
    {
        Intent it= new Intent(this, MainActivity.class);
        startActivity(it);
    }

    
    public void atualizar(MenuItem item)
    {
        AdapterView.AdapterContextMenuInfo menuInfo= (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        final Aluno alunoAtualizar= alunosfiltrados.get(menuInfo.position);

        Intent it = new Intent(this, MainActivity.class);
        it.putExtra("aluno", alunoAtualizar);
        startActivity(it);
    }

    //atualizar a lista
    @Override
    protected void onResume()
    {

        super.onResume();
        alunos = dao.obtertodos();
        alunosfiltrados.clear();
        alunosfiltrados.addAll(alunos);
        lista.invalidateViews();
    }
}
